Book vs Phone Image Dataset

Files:
p1.jpg - p6.jpg = Books (Class 0)
c1.jpg - c6.jpg = Phones (Class 1)

For the supplied lab code:
Training: p1-p5 + c1-c5 = 10 images
Testing:  p6 + c6 = 2 images

This dataset is a small demonstration dataset for the R + EBImage + Keras lab.
