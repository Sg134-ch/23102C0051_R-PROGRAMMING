
# ============================================================
# BOOK VS PHONE IMAGE CLASSIFICATION
# R + EBImage + keras3 + TensorFlow
# ============================================================

options(repos = c(CRAN = "https://cloud.r-project.org"))

# Use the exact Python executable from the Colab runtime.
python_path <- readLines("/content/colab_python_path.txt", n = 1)
Sys.setenv(RETICULATE_PYTHON = python_path)

library(EBImage)
library(keras3)
library(reticulate)

use_python(python_path, required = TRUE)

cat("\n===== PYTHON CONFIGURATION =====\n")
print(py_config())

# Select TensorFlow backend.
use_backend("tensorflow")

set.seed(123)

# ------------------------------------------------------------
# 1. Read images
# ------------------------------------------------------------
setwd("/content/book_phone_dataset")

pics <- c(
  "p1.jpg","p2.jpg","p3.jpg","p4.jpg","p5.jpg","p6.jpg",
  "c1.jpg","c2.jpg","c3.jpg","c4.jpg","c5.jpg","c6.jpg"
)

mypic <- vector("list", length(pics))

for (i in seq_along(pics)) {
  mypic[[i]] <- readImage(pics[i])
}

cat("\n===== IMAGE INFORMATION =====\n")
cat("Number of images:", length(mypic), "\n")
cat("First image dimensions:", paste(dim(mypic[[1]]), collapse = " x "), "\n")
print(summary(mypic[[1]]))
str(mypic, max.level = 1)

# ------------------------------------------------------------
# 2. Explore images
# ------------------------------------------------------------
png("/content/book_example.png", width = 700, height = 500)
display(mypic[[1]], method = "raster")
dev.off()

png("/content/phone_example.png", width = 700, height = 500)
display(mypic[[7]], method = "raster")
dev.off()

png("/content/image_histogram.png", width = 700, height = 500)
hist(mypic[[2]], main = "Pixel Histogram: Book Image p2")
dev.off()

# ------------------------------------------------------------
# 3. Resize to 28 x 28 x 3
# 28 * 28 * 3 = 2352 input values
# ------------------------------------------------------------
for (i in seq_along(mypic)) {
  mypic[[i]] <- channel(mypic[[i]], "rgb")
  mypic[[i]] <- resize(mypic[[i]], w = 28, h = 28)
}

cat("\n===== AFTER RESIZE =====\n")
print(dim(mypic[[1]]))

# ------------------------------------------------------------
# 4. Flatten / reshape
# ------------------------------------------------------------
for (i in seq_along(mypic)) {
  arr <- as.array(mypic[[i]])
  mypic[[i]] <- array_reshape(arr, c(2352))
}

cat("\n===== AFTER RESHAPE =====\n")
print(dim(mypic[[1]]))

# ------------------------------------------------------------
# 5. Training and testing data
# ------------------------------------------------------------
# Book = 0
# Phone = 1

trainx <- NULL

for (i in 1:5) {
  trainx <- rbind(trainx, mypic[[i]])
}

for (i in 7:11) {
  trainx <- rbind(trainx, mypic[[i]])
}

testx <- rbind(mypic[[6]], mypic[[12]])

trainx <- pmin(pmax(trainx, 0), 1)
testx  <- pmin(pmax(testx, 0), 1)

trainy <- c(0,0,0,0,0,1,1,1,1,1)
testy  <- c(0,1)

cat("\n===== DATA SHAPES =====\n")
cat("trainx:", paste(dim(trainx), collapse = " x "), "\n")
cat("testx :", paste(dim(testx), collapse = " x "), "\n")
cat("trainy:", paste(trainy, collapse = ", "), "\n")
cat("testy :", paste(testy, collapse = ", "), "\n")

# ------------------------------------------------------------
# 6. One-hot encoding
# ------------------------------------------------------------
trainLabels <- to_categorical(trainy, num_classes = 2)
testLabels  <- to_categorical(testy, num_classes = 2)

cat("\n===== ONE-HOT TRAIN LABELS =====\n")
print(trainLabels)

# ------------------------------------------------------------
# 7. Model
# ------------------------------------------------------------
model <- keras_model_sequential(input_shape = c(2352)) |>
  layer_dense(units = 256, activation = "relu") |>
  layer_dense(units = 128, activation = "relu") |>
  layer_dense(units = 2, activation = "softmax")

cat("\n===== MODEL =====\n")
print(model)

# ------------------------------------------------------------
# 8. Compile
# ------------------------------------------------------------
model |> compile(
  loss = "categorical_crossentropy",
  optimizer = optimizer_rmsprop(),
  metrics = c("accuracy")
)

# ------------------------------------------------------------
# 9. Train
# ------------------------------------------------------------
cat("\n===== TRAINING =====\n")

history <- model |> fit(
  x = trainx,
  y = trainLabels,
  epochs = 30,
  batch_size = 2,
  validation_split = 0.2,
  verbose = 1
)

# ------------------------------------------------------------
# 10. Training history
# ------------------------------------------------------------
png("/content/training_history.png", width = 900, height = 600)
plot(history, main = "Book vs Phone Training History")
dev.off()

# ------------------------------------------------------------
# 11. Evaluate
# ------------------------------------------------------------
cat("\n===== TRAINING EVALUATION =====\n")
train_eval <- evaluate(model, trainx, trainLabels, verbose = 0)
print(train_eval)

cat("\n===== TEST EVALUATION =====\n")
test_eval <- evaluate(model, testx, testLabels, verbose = 0)
print(test_eval)

# ------------------------------------------------------------
# 12. Predictions on training data
# ------------------------------------------------------------
train_prob <- predict(model, trainx, verbose = 0)
train_pred <- max.col(train_prob) - 1L

cat("\n===== TRAINING CONFUSION TABLE =====\n")
print(table(Predicted = train_pred, Actual = trainy))

# ------------------------------------------------------------
# 13. Predictions on test data
# ------------------------------------------------------------
test_prob <- predict(model, testx, verbose = 0)
test_pred <- max.col(test_prob) - 1L

class_names <- c("Book", "Phone")

test_results <- data.frame(
  Image = c("p6.jpg", "c6.jpg"),
  Actual_Class = class_names[testy + 1],
  Predicted_Class = class_names[test_pred + 1],
  Book_Probability = round(test_prob[,1], 6),
  Phone_Probability = round(test_prob[,2], 6),
  Correct = test_pred == testy
)

cat("\n===== TEST PREDICTIONS =====\n")
print(test_results)

cat("\n===== TEST CONFUSION MATRIX =====\n")
print(
  table(
    Predicted = factor(test_pred, levels = 0:1, labels = class_names),
    Actual = factor(testy, levels = 0:1, labels = class_names)
  )
)

# ------------------------------------------------------------
# 14. Save deliverables
# ------------------------------------------------------------
write.csv(
  test_results,
  "/content/book_phone_test_predictions.csv",
  row.names = FALSE
)

write.csv(
  data.frame(
    Method = c("Training", "Test"),
    Accuracy = c(
      mean(train_pred == trainy),
      mean(test_pred == testy)
    )
  ),
  "/content/book_phone_accuracy.csv",
  row.names = FALSE
)

# Save model.
save_model(
  model,
  "/content/book_phone_model.keras",
  overwrite = TRUE
)

cat("\n===== COMPLETE =====\n")
cat("Generated:\n")
cat("✓ book_phone_image_classification.R\n")
cat("✓ book_phone_test_predictions.csv\n")
cat("✓ book_phone_accuracy.csv\n")
cat("✓ book_phone_model.keras\n")
cat("✓ training_history.png\n")
cat("✓ book_example.png\n")
cat("✓ phone_example.png\n")
cat("✓ image_histogram.png\n")
