# ============================================================
# ASSIGNMENT 2 - LAB 4
# Advanced Missing Data Handling
# Topic: NA, NULL, NaN, Missing-Value Detection and Imputation
# Dataset: UCI Adult / Census Income Dataset
# ============================================================

# Required packages:
# naniar, skimr

if (!requireNamespace("naniar", quietly = TRUE))
  install.packages("naniar")

if (!requireNamespace("skimr", quietly = TRUE))
  install.packages("skimr")

library(naniar)
library(skimr)

# -----------------------------
# 1. Load UCI Adult dataset
# -----------------------------
adult_url <- "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"

adult <- read.csv(
  adult_url,
  header = FALSE,
  strip.white = TRUE,
  na.strings = "?"
)

colnames(adult) <- c(
  "age","workclass","fnlwgt","education","education_num",
  "marital_status","occupation","relationship","race","sex",
  "capital_gain","capital_loss","hours_per_week",
  "native_country","income"
)

# -----------------------------
# 2. Introduce missing/invalid values
# -----------------------------
set.seed(123)

age_na_rows <- sample(seq_len(nrow(adult)), 5)
nan_rows <- sample(setdiff(seq_len(nrow(adult)), age_na_rows), 5)
blank_rows <- sample(
  setdiff(seq_len(nrow(adult)), c(age_na_rows, nan_rows)), 5
)
invalid_age_rows <- sample(
  setdiff(seq_len(nrow(adult)), c(age_na_rows, nan_rows, blank_rows)), 5
)

adult$age[age_na_rows] <- NA
adult$capital_gain[nan_rows] <- NaN
adult$workclass[blank_rows] <- ""
adult$age[invalid_age_rows] <- 999

# -----------------------------
# 3. Detect NA, NaN, NULL, blanks and 999
# -----------------------------
cat("\nNA in age:", sum(is.na(adult$age)), "\n")
cat("NaN in capital_gain:", sum(is.nan(adult$capital_gain)), "\n")

demo_object <- NULL
cat("is.null(demo_object):", is.null(demo_object), "\n")

blank_workclass <- adult$workclass == ""
cat("Blank workclass:", sum(blank_workclass, na.rm = TRUE), "\n")

cat("Age = 999:", sum(adult$age == 999, na.rm = TRUE), "\n")

cat("\nMissing summary before cleaning:\n")
before_summary <- miss_var_summary(adult)
print(before_summary)

# -----------------------------
# 4. Before-cleaning statistics
# -----------------------------
missing_before <- sum(is.na(adult))
missing_pct_before <- 100 * missing_before / (nrow(adult) * ncol(adult))

# -----------------------------
# 5. Custom median imputation function
# -----------------------------
median_impute <- function(x) {
  if (!is.numeric(x))
    stop("Input must be numeric.")

  if (all(is.na(x)))
    stop("All values are missing; median cannot be calculated.")

  med <- median(x, na.rm = TRUE)
  x[is.na(x)] <- med
  x
}

# -----------------------------
# 6. Clean impossible values and blanks
# -----------------------------
adult$age[adult$age == 999] <- NA

categorical_columns <- c(
  "workclass", "occupation", "native_country"
)

for (column in categorical_columns) {
  adult[[column]][
    !is.na(adult[[column]]) & adult[[column]] == ""
  ] <- "Unknown"
}

# -----------------------------
# 7. Remove NaN appropriately
# -----------------------------
# NaN is included in is.na() for numeric vectors.
# Convert NaN to NA before median imputation.
adult$capital_gain[is.nan(adult$capital_gain)] <- NA

# -----------------------------
# 8. Median imputation
# -----------------------------
numeric_columns <- c(
  "age", "fnlwgt", "education_num",
  "capital_gain", "capital_loss", "hours_per_week"
)

for (column in numeric_columns) {
  adult[[column]] <- median_impute(adult[[column]])
}

# -----------------------------
# 9. Complete/incomplete observations
# -----------------------------
complete_flag <- complete.cases(adult)

cat("\nComplete rows:", sum(complete_flag), "\n")
cat("Incomplete rows:", sum(!complete_flag), "\n")

# -----------------------------
# 10. After-cleaning summary
# -----------------------------
missing_after <- sum(is.na(adult))
missing_pct_after <- 100 * missing_after / (nrow(adult) * ncol(adult))

after_summary <- miss_var_summary(adult)

cat("\nMissing summary after cleaning:\n")
print(after_summary)

# -----------------------------
# 11. Before vs after report
# -----------------------------
missing_comparison <- data.frame(
  Stage = c("Before Cleaning", "After Cleaning"),
  Missing_Count = c(missing_before, missing_after),
  Missing_Percentage = c(missing_pct_before, missing_pct_after)
)

print(missing_comparison)
write.csv(
  missing_comparison,
  "lab4_missing_before_after.csv",
  row.names = FALSE
)

# -----------------------------
# 12. Missingness visualization
# -----------------------------
# Save a visualization for the report.
png("lab4_missingness_after.png", width = 1400, height = 900)
print(vis_miss(adult[sample(seq_len(nrow(adult)),
                            min(1000, nrow(adult))), ]))
dev.off()

# Also generate an upset-style pattern if enough combinations exist.
png("lab4_missingness_pattern.png", width = 1400, height = 900)
print(gg_miss_upset(adult[sample(seq_len(nrow(adult)),
                                 min(1000, nrow(adult))), ]))
dev.off()

# -----------------------------
# 13. skimr output
# -----------------------------
skim_output <- capture.output(skim(adult))
writeLines(skim_output, "lab4_skim_output.txt")

cat("\nSKIMR OUTPUT:\n")
cat(paste(skim_output, collapse = "\n"))

# -----------------------------
# 14. Validation
# -----------------------------
validation <- data.frame(
  Age_999_Remaining = sum(adult$age == 999, na.rm = TRUE),
  Blank_Workclass_Remaining =
    sum(adult$workclass == "", na.rm = TRUE),
  Blank_Occupation_Remaining =
    sum(adult$occupation == "", na.rm = TRUE),
  Blank_NativeCountry_Remaining =
    sum(adult$native_country == "", na.rm = TRUE),
  Total_NA_Remaining = sum(is.na(adult)),
  Total_NaN_Remaining = sum(is.nan(as.matrix(adult)))
)

print(validation)
write.csv(validation, "lab4_validation_summary.csv", row.names = FALSE)

# -----------------------------
# 15. Export required deliverable
# -----------------------------
write.csv(adult, "cleaned_adult_data.csv", row.names = FALSE)

cat("\nLAB 4 COMPLETE.\n")
cat("Generated: cleaned_adult_data.csv, lab4_missing_before_after.csv,\n")
cat("lab4_missingness_after.png, lab4_missingness_pattern.png,\n")
cat("lab4_skim_output.txt, lab4_validation_summary.csv\n")
