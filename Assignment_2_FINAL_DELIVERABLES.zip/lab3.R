# ============================================================
# ASSIGNMENT 2 - LAB 3
# Control Flow for Data Cleaning
# Topic: Loops, Functions, and Error Handling in R
# Dataset: UCI Heart Disease Dataset
# ============================================================

# This script:
# 1. Loads the UCI Cleveland Heart Disease data.
# 2. Introduces negative, missing, and >250 BP values.
# 3. Cleans trestbps using a custom if-else function.
# 4. Uses tryCatch() for safe mean and chol/trestbps ratio.
# 5. Compares loop-based and vectorized cleaning.
# 6. Validates and exports cleaned_heart_data.csv.

# -----------------------------
# 1. Load dataset
# -----------------------------
heart_url <- "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data"

heart <- read.csv(
  heart_url,
  header = FALSE,
  na.strings = "?",
  strip.white = TRUE
)

colnames(heart) <- c(
  "age","sex","cp","trestbps","chol","fbs","restecg",
  "thalach","exang","oldpeak","slope","ca","thal","target"
)

heart$trestbps <- as.numeric(heart$trestbps)
heart$chol <- as.numeric(heart$chol)

cat("Dataset dimensions:", dim(heart), "\n")
print(head(heart))

# -----------------------------
# 2. Introduce realistic data-entry problems
# -----------------------------
set.seed(123)

negative_rows <- sample(seq_len(nrow(heart)), 3)
missing_rows <- sample(
  setdiff(seq_len(nrow(heart)), negative_rows), 3
)
extreme_rows <- sample(
  setdiff(seq_len(nrow(heart)), c(negative_rows, missing_rows)), 3
)

heart$trestbps[negative_rows] <- -50
heart$trestbps[missing_rows] <- NA
heart$trestbps[extreme_rows] <- c(310, 350, 400)

# -----------------------------
# 3. Custom BP-cleaning function
# -----------------------------
clean_bp <- function(bp) {
  if (is.na(bp)) {
    return(NA_real_)
  } else if (bp < 0) {
    return(NA_real_)
  } else if (bp > 250) {
    return(250)
  } else {
    return(bp)
  }
}

# Demonstration
cat("\nCustom function test:\n")
print(sapply(c(-20, 120, 260, NA, 180), clean_bp))

# Apply function
heart$trestbps_clean <- sapply(heart$trestbps, clean_bp)

# -----------------------------
# 4. tryCatch(): safe mean
# -----------------------------
safe_mean_bp <- function(bp) {
  tryCatch({
    if (length(bp) == 0) stop("BP vector is empty.")
    if (all(is.na(bp))) stop("No valid BP observations.")
    mean(bp, na.rm = TRUE)
  }, error = function(e) {
    message("ERROR: ", e$message)
    NA_real_
  }, warning = function(w) {
    message("WARNING: ", w$message)
    mean(bp, na.rm = TRUE)
  })
}

cat("\nSafe mean BP:\n")
print(safe_mean_bp(heart$trestbps_clean))

# -----------------------------
# 5. tryCatch(): safe ratio
# -----------------------------
safe_ratio <- function(chol, bp) {
  tryCatch({
    if (is.na(chol) || is.na(bp))
      stop("Cholesterol or BP is NA.")
    if (bp == 0)
      stop("BP denominator cannot be zero.")
    if (bp < 0)
      stop("BP cannot be negative.")
    if (chol < 0)
      stop("Cholesterol cannot be negative.")
    chol / bp
  }, error = function(e) {
    message("ERROR: ", e$message)
    NA_real_
  })
}

heart$chol_bp_ratio <- mapply(
  safe_ratio,
  heart$chol,
  heart$trestbps_clean
)

# Demonstrate error handling
print(safe_ratio(200, 0))
print(safe_ratio(200, NA))

# -----------------------------
# 6. Loop-based cleaning
# -----------------------------
bp_loop <- heart$trestbps
loop_clean <- numeric(length(bp_loop))

loop_time <- system.time({
  for (i in seq_along(bp_loop)) {
    if (is.na(bp_loop[i])) {
      loop_clean[i] <- NA_real_
    } else if (bp_loop[i] < 0) {
      loop_clean[i] <- NA_real_
    } else if (bp_loop[i] > 250) {
      loop_clean[i] <- 250
    } else {
      loop_clean[i] <- bp_loop[i]
    }
  }
})

# -----------------------------
# 7. Vectorized cleaning
# -----------------------------
vector_clean <- bp_loop

vector_time <- system.time({
  vector_clean[!is.na(vector_clean) & vector_clean < 0] <- NA_real_
  vector_clean[!is.na(vector_clean) & vector_clean > 250] <- 250
})

# Compare results
cat("\nLoop and vectorized results identical:\n")
print(isTRUE(all.equal(loop_clean, vector_clean)))

benchmark <- data.frame(
  Method = c("For loop", "Vectorized"),
  User_seconds = c(loop_time[["user.self"]], vector_time[["user.self"]]),
  System_seconds = c(loop_time[["sys.self"]], vector_time[["sys.self"]]),
  Elapsed_seconds = c(loop_time[["elapsed"]], vector_time[["elapsed"]])
)

print(benchmark)
write.csv(benchmark, "lab3_benchmark.csv", row.names = FALSE)

# -----------------------------
# 8. Final cleaned dataset
# -----------------------------
heart$trestbps <- vector_clean
heart$trestbps_clean <- NULL

# -----------------------------
# 9. Validation
# -----------------------------
validation <- data.frame(
  Missing_BP = sum(is.na(heart$trestbps)),
  Min_BP = min(heart$trestbps, na.rm = TRUE),
  Max_BP = max(heart$trestbps, na.rm = TRUE),
  Mean_BP = mean(heart$trestbps, na.rm = TRUE),
  Median_BP = median(heart$trestbps, na.rm = TRUE),
  Negative_Remaining = sum(heart$trestbps < 0, na.rm = TRUE),
  Above_250_Remaining = sum(heart$trestbps > 250, na.rm = TRUE)
)

cat("\nValidation:\n")
print(validation)

stopifnot(
  validation$Negative_Remaining == 0,
  validation$Above_250_Remaining == 0
)

write.csv(validation, "lab3_validation_summary.csv", row.names = FALSE)

# -----------------------------
# 10. Export required deliverable
# -----------------------------
write.csv(heart, "cleaned_heart_data.csv", row.names = FALSE)

cat("\nLAB 3 COMPLETE.\n")
cat("Generated: cleaned_heart_data.csv, lab3_benchmark.csv, lab3_validation_summary.csv\n")
