# Assignment 2 – R Programming
## Lab 3 and Lab 4 Deliverables

### Lab 3 – Short Conclusion
The `trestbps` variable of the UCI Heart Disease dataset was cleaned using a custom `if-else` function. Negative blood-pressure values were converted to `NA`, values above 250 mmHg were capped at 250, and valid values were retained. `tryCatch()` was used to safely calculate mean BP and the cholesterol-to-BP ratio while handling invalid denominators and missing values. Loop-based and vectorized approaches were implemented and timed. Both produced equivalent cleaned results; vectorized R operations are expected to be more efficient for larger datasets because they reduce explicit iteration.

### Lab 4 – Short Interpretation
The UCI Adult dataset was examined for `NA`, `NaN`, `NULL`, blank strings, and impossible age values. Age values of 999 were converted to `NA`, blank categorical values were changed to `Unknown`, and selected numeric missing values were imputed using a custom median-imputation function. Before/after missing-value summaries were produced, missingness was visualized with `naniar`, and the final data was validated using `complete.cases()` and `skimr::skim()`.

### Required generated files
Lab 3:
- cleaned_heart_data.csv
- lab3.R
- lab3_benchmark.csv
- lab3_validation_summary.csv

Lab 4:
- cleaned_adult_data.csv
- lab4.R
- lab4_missing_before_after.csv
- lab4_missingness_after.png
- lab4_missingness_pattern.png
- lab4_skim_output.txt
- lab4_validation_summary.csv

Run the two R scripts in Google Colab/RStudio. The scripts automatically download the datasets and generate the CSVs and validation artifacts.
