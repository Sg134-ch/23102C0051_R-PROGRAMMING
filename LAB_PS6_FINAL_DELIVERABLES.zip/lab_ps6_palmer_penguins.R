
# LAB PS 6 - STATISTICAL ANALYSIS OF PALMER PENGUINS
packages <- c("ggplot2","dplyr","e1071","car")
for(p in packages) if(!requireNamespace(p,quietly=TRUE)) install.packages(p,repos="https://cloud.r-project.org")
library(ggplot2); library(dplyr); library(e1071); library(car)

# Load UCI file if downloaded by Colab; otherwise use standard Palmer Penguins package
if(file.exists("penguins.csv")) {
  penguins <- read.csv("penguins.csv",stringsAsFactors=FALSE)
} else {
  if(!requireNamespace("palmerpenguins",quietly=TRUE))
    install.packages("palmerpenguins",repos="https://cloud.r-project.org")
  penguins <- as.data.frame(palmerpenguins::penguins)
}
if("culmen_length_mm"%in%names(penguins)) names(penguins)[names(penguins)=="culmen_length_mm"]<-"bill_length_mm"
if("culmen_depth_mm"%in%names(penguins)) names(penguins)[names(penguins)=="culmen_depth_mm"]<-"bill_depth_mm"
penguins$species<-factor(penguins$species); penguins$sex<-factor(penguins$sex)

cat("DATASET:",nrow(penguins),"rows,",ncol(penguins),"columns\n")
print(head(penguins)); cat("\nMissing values:\n"); print(colSums(is.na(penguins)))

mass_data<-penguins%>%filter(!is.na(body_mass_g),!is.na(species))
mass_sex<-penguins%>%filter(!is.na(body_mass_g),!is.na(sex))
mass_two_way<-penguins%>%filter(!is.na(body_mass_g),!is.na(species),!is.na(sex))

# 1. DESCRIPTIVE STATISTICS
descriptive<-mass_data%>%group_by(species)%>%summarise(
 N=n(),Mean=mean(body_mass_g),Median=median(body_mass_g),
 Minimum=min(body_mass_g),Maximum=max(body_mass_g),Variance=var(body_mass_g),
 SD=sd(body_mass_g),Q1=quantile(body_mass_g,.25),Q3=quantile(body_mass_g,.75),
 IQR=IQR(body_mass_g),Skewness=e1071::skewness(body_mass_g,type=2),
 Kurtosis=e1071::kurtosis(body_mass_g,type=2),.groups="drop")
write.csv(descriptive,"descriptive_statistics.csv",row.names=FALSE)
print(descriptive)

# Visualizations
ggsave("01_body_mass_histogram.png",ggplot(mass_data,aes(body_mass_g))+geom_histogram(bins=25,fill="steelblue")+
labs(title="Histogram of Penguin Body Mass",x="Body Mass (g)",y="Frequency"),width=8,height=5)
ggsave("02_species_body_mass_boxplot.png",ggplot(mass_data,aes(species,body_mass_g,fill=species))+geom_boxplot()+
labs(title="Body Mass by Penguin Species",x="Species",y="Body Mass (g)")+theme(legend.position="none"),width=8,height=5)
ggsave("03_body_mass_density.png",ggplot(mass_data,aes(body_mass_g,color=species,fill=species))+geom_density(alpha=.2)+
labs(title="Body Mass Density by Species",x="Body Mass (g)",y="Density"),width=8,height=5)
ggsave("04_sex_body_mass_boxplot.png",ggplot(mass_sex,aes(sex,body_mass_g,fill=sex))+geom_boxplot()+
labs(title="Body Mass by Sex",x="Sex",y="Body Mass (g)")+theme(legend.position="none"),width=8,height=5)

# 2. MALE VS FEMALE HYPOTHESIS TEST
male<-mass_sex$body_mass_g[mass_sex$sex=="male"]; female<-mass_sex$body_mass_g[mass_sex$sex=="female"]
sh_male<-shapiro.test(male); sh_female<-shapiro.test(female)
png("05_QQ_male.png",800,600); qqnorm(male,main="QQ Plot - Male Body Mass"); qqline(male); dev.off()
png("06_QQ_female.png",800,600); qqnorm(female,main="QQ Plot - Female Body Mass"); qqline(female); dev.off()
tt<-t.test(male,female,var.equal=FALSE)
pooled<-sqrt(((length(male)-1)*var(male)+(length(female)-1)*var(female))/(length(male)+length(female)-2))
d<-(mean(male)-mean(female))/pooled
tres<-data.frame(Male_Mean=mean(male),Female_Mean=mean(female),Difference=mean(male)-mean(female),
 T=unname(tt$statistic),DF=unname(tt$parameter),P_Value=tt$p.value,
 CI_Lower=tt$conf.int[1],CI_Upper=tt$conf.int[2],Cohens_d=d)
write.csv(tres,"t_test_results.csv",row.names=FALSE)
write.csv(data.frame(Sex=c("Male","Female"),W=c(sh_male$statistic,sh_female$statistic),
 P_Value=c(sh_male$p.value,sh_female$p.value)),"sex_shapiro_tests.csv",row.names=FALSE)
print(tt); print(tres)

# 3. ONE-WAY ANOVA + ASSUMPTIONS + TUKEY
anova_model<-aov(body_mass_g~species,data=mass_data); anova_table<-as.data.frame(summary(anova_model)[[1]])
anova_table$Term<-rownames(anova_table); rownames(anova_table)<-NULL
write.csv(anova_table,"one_way_anova_table.csv",row.names=FALSE); print(anova_table)
species_shapiro<-mass_data%>%group_by(species)%>%summarise(W=shapiro.test(body_mass_g)$statistic,
 P_Value=shapiro.test(body_mass_g)$p.value,.groups="drop")
write.csv(species_shapiro,"species_shapiro_tests.csv",row.names=FALSE); print(species_shapiro)
lev<-car::leveneTest(body_mass_g~species,data=mass_data); write.csv(as.data.frame(lev),"levene_test.csv",row.names=FALSE); print(lev)
png("07_ANOVA_QQ_plot.png",800,600); qqnorm(residuals(anova_model),main="QQ Plot of ANOVA Residuals"); qqline(residuals(anova_model)); dev.off()
if(anova_table$`Pr(>F)`[1]<.05){
  tuk<-TukeyHSD(anova_model); tukdf<-as.data.frame(tuk$species); tukdf$Comparison<-rownames(tukdf); rownames(tukdf)<-NULL
  write.csv(tukdf,"tukey_hsd_results.csv",row.names=FALSE); print(tuk)
} else write.csv(data.frame(Note="ANOVA not significant"),"tukey_hsd_results.csv",row.names=FALSE)

# 4. KRUSKAL-WALLIS
kw<-kruskal.test(body_mass_g~species,data=mass_data)
write.csv(data.frame(Chi_Squared=unname(kw$statistic),DF=unname(kw$parameter),P_Value=kw$p.value),
"kruskal_wallis_results.csv",row.names=FALSE); print(kw)

# 5. TWO-WAY ANOVA
tw<-aov(body_mass_g~species*sex,data=mass_two_way); twtab<-as.data.frame(summary(tw)[[1]])
twtab$Term<-rownames(twtab); rownames(twtab)<-NULL; write.csv(twtab,"two_way_anova_table.csv",row.names=FALSE); print(twtab)
ggsave("08_species_sex_interaction.png",ggplot(mass_two_way,aes(species,body_mass_g,color=sex,group=sex))+
stat_summary(fun=mean,geom="point",size=3)+stat_summary(fun=mean,geom="line")+
labs(title="Mean Body Mass by Species and Sex",x="Species",y="Mean Body Mass (g)"),width=8,height=5)

# 6. FLIPPER LENGTH
fl<-penguins%>%filter(!is.na(flipper_length_mm),!is.na(species))
fa<-aov(flipper_length_mm~species,data=fl); fat<-as.data.frame(summary(fa)[[1]])
fat$Term<-rownames(fat); rownames(fat)<-NULL; write.csv(fat,"flipper_one_way_anova.csv",row.names=FALSE); print(fat)
fkw<-kruskal.test(flipper_length_mm~species,data=fl)
write.csv(data.frame(Chi_Squared=unname(fkw$statistic),DF=unname(fkw$parameter),P_Value=fkw$p.value),
"flipper_kruskal_wallis.csv",row.names=FALSE); print(fkw)
ggsave("09_flipper_length_by_species.png",ggplot(fl,aes(species,flipper_length_mm,fill=species))+geom_boxplot()+
labs(title="Flipper Length by Penguin Species",x="Species",y="Flipper Length (mm)")+theme(legend.position="none"),width=8,height=5)

means<-mass_data%>%group_by(species)%>%summarise(Mean=mean(body_mass_g),SE=sd(body_mass_g)/sqrt(n()),.groups="drop")
ggsave("10_species_mean_comparison.png",ggplot(means,aes(species,Mean,fill=species))+geom_col()+
geom_errorbar(aes(ymin=Mean-SE,ymax=Mean+SE),width=.15)+labs(title="Mean Body Mass by Species (± SE)",x="Species",y="Mean Body Mass (g)")+theme(legend.position="none"),width=8,height=5)

# 7. INTERPRETATION + VALIDATION
psex<-tt$p.value; panova<-anova_table$`Pr(>F)`[1]; pkw<-kw$p.value; pfl<-fat$`Pr(>F)`[1]
interp<-c("STATISTICAL INTERPRETATION",
paste0("Male-vs-female p-value = ",signif(psex,5),". Sex difference is ",ifelse(psex<.05,"statistically significant.","not statistically significant.")),
paste0("95% CI for male minus female mean body mass = [",round(tt$conf.int[1],2),", ",round(tt$conf.int[2],2),"] g."),
paste0("Cohen's d = ",round(d,3),"."),
paste0("One-way ANOVA species p-value = ",signif(panova,5),". Species effect is ",ifelse(panova<.05,"significant.","not significant.")),
paste0("Kruskal-Wallis p-value = ",signif(pkw,5),"."),
paste0("Flipper-length ANOVA p-value = ",signif(pfl,5),"."),
"Conclusion: The workflow combines descriptive statistics, assumption checks, parametric and non-parametric tests, effect size estimation and visualization.")
writeLines(interp,"statistical_interpretation.txt"); cat(paste(interp,collapse="\n"),"\n")
validation<-data.frame(Check=c("Dataset loaded","Descriptive statistics","t-test","One-way ANOVA","Tukey output","Kruskal-Wallis","Two-way ANOVA","Flipper analysis","Visualizations"),
Result=c(nrow(penguins)>0,file.exists("descriptive_statistics.csv"),file.exists("t_test_results.csv"),file.exists("one_way_anova_table.csv"),file.exists("tukey_hsd_results.csv"),file.exists("kruskal_wallis_results.csv"),file.exists("two_way_anova_table.csv"),file.exists("flipper_one_way_anova.csv"),file.exists("10_species_mean_comparison.png")))
write.csv(validation,"validation_summary.csv",row.names=FALSE); print(validation)
cat("LAB PS 6 COMPLETED SUCCESSFULLY\n")
